/*
 * Arduino.c
 *
 * Created: 23.10.2017 10:07:28
 *  Author: jornbh
 */ 


#include <avr/io.h>

#include "main.h"
#include "USART/usart.h"
#include "CAN/can.h"


void init() {
	usart_init ( MYUBRR );
	printf_char("USART INITIALIZED\n");
	can_init();
}

int main(void) {

	init();
	
	printf_char("Hello World I`m Node2\n");
	struct can_message recv, msg;
	char stri[5] = {1,2,3,4,5};
    while(1) {

//		enum RECIEVE_BUFFER buffer = can_findFullReceiveBuffer(status);
		
		enum RECIEVE_BUFFER buffer = can_findReceiveBuffer();
		if(buffer != INVALID_RECIEVE_BUFFER) {
			recv = can_recieve_message(buffer);
			can_print_message(&recv);
		}
		
		
		msg = can_create_massage(8, 2, stri);
		can_send_message(&msg);
    }
}