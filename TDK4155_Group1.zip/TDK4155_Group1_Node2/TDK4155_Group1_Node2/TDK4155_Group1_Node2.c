/*
 * TDK4155_Group1_Node2.c
 *
 * Created: 25.10.2017 10:57:28
 *  Author: huberts
 */ 


#include <avr/io.h>

int main(void)
{
    while(1)
    {
        //TODO:: Please write your application code 
    }
}