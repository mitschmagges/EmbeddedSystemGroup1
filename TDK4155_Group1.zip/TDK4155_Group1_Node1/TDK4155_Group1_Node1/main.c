/*
 * TDT4200Group1.c
 *
 * Created: 02.10.2017 13:17:16
 *  Author: hubi
 */ 

#define FOSC 4915200 // clock speed
#define BAUD 9600
#define MYUBRR FOSC/16/BAUD-1

#include "main.h"
#include "MCP/mcp.h"
#include "./CAN/can_buffer.h"
void XMEM_Init() {
	MCUCR |= (1<<SRE);
	SFIOR |= (1<<XMM2);
}

void init() {
	usart_init( MYUBRR );
	XMEM_Init();
	calibrateJoystick();
	DDRB &= ~0b0011;
	oled_init();
	oled_reset();
	fdevopen(oled_putchar, usart_getchar);
	oled_reset();
	buttons_init();
	can_init();
}

int main(void) {
	init();
	
	char status, canInterrupt;
	
	while(1) {

		printf_char("Beginning of main loop\n");
		
		char stri[5] = {1,2,3,4,5};
		
		struct can_message msg = can_create_massage(42, 5, stri);
		
		//can_print_message(&msg);
		
		//status = mcp_readStatus();
		mcp_read(MCP_CANCTRL, &canInterrupt, 1);
		printf_char("CanInterrupt: ");
		printf_int(canInterrupt);
		printf_char("\n");
		
		can_send_message(&msg);
		
		if (can_findReceiveBuffer() != INVALID_RECIEVE_BUFFER){
			msg = can_recieve_message(RXB0);
			can_print_message(&msg);
		}
		
		status = mcp_readStatus();
	}
}